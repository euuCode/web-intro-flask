from flask import render_template, request, jsonify

def setup_routes(app):
    @app.route('/')
    def index():
        return render_template("hello.html")

    @app.route('/hello/')
    @app.route('/hello/<nome>')
    def hello(nome=None):
        return render_template('hello.html', name=nome)

    @app.route('/show/<int:id>')
    def show(id):
        return f'Valor recebido id = {id}'

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            return f'Login recebido: {username}'
        return render_template('login.html')

    @app.route('/api')
    def api():
        return jsonify({
            "mensagem": "Hello Json!",
            "status": "ok",
            "autor": "Marcio Ferreira",
            "RA": "324120976"
        })

    @app.errorhandler(404)
    def page_not_found(error):
        return render_template('error.html'), 404
